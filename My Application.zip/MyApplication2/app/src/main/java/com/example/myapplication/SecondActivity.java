package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
    }
    public void login(View view) {
        EditText editTextName = findViewById(R.id.editTextName);
        EditText editTextPassword = findViewById(R.id.editTextPassword);
        String name = editTextName.getText().toString();
        String password = editTextPassword.getText().toString();
        Intent intent = new Intent(this, category.class);
        startActivity(intent);
    }

    public void signUp(View view) {
        // If Sign Up is clicked, open the SignUpActivity
        Intent intent = new Intent(this, MainActivity3.class);
        startActivity(intent);
    }
}