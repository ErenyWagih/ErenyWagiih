package com.example.myapplication;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;

import androidx.appcompat.app.AppCompatActivity;
public class category extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);
    }
    public void onNextButtonClick(View view) {
        CheckBox checkBoxBuy = findViewById(R.id.checkBox);
        CheckBox checkBoxSell = findViewById(R.id.checkBox2);
        CheckBox checkBoxReplace = findViewById(R.id.checkBox3);

        if (checkBoxBuy.isChecked()) {
            // Navigate to Buy Activity
            Intent intent = new Intent(this, BuyActivity.class);
            startActivity(intent);
        } else if (checkBoxSell.isChecked()) {
            // Navigate to Sell Activity
            Intent intent = new Intent(this, SellActivity.class);
            startActivity(intent);
        } else if (checkBoxReplace.isChecked()) {
            // Navigate to Replace Activity
            Intent intent = new Intent(this, ReplaceActivity.class);
            startActivity(intent);
        }
    }}