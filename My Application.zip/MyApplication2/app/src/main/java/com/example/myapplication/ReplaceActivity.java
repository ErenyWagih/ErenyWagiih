package com.example.myapplication;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class ReplaceActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_replace);

        EditText editTextItemDescription = findViewById(R.id.editTextItemDescriptionReplace);
        Button btnBack = findViewById(R.id.btnBackReplace);
        Button btnNext = findViewById(R.id.btnNextReplace);

        btnBack.setOnClickListener(v -> {
            // Navigate back to Category screen
            Intent intent = new Intent(ReplaceActivity.this, MainActivity.class);
            startActivity(intent);
        });
    }
}
